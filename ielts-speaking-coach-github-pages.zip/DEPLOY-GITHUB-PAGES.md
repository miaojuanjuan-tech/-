# Deploy to GitHub Pages

This folder is ready for GitHub Pages.

## Files to upload

- `index.html`
- `ielts-speaking-coach.html`

## Fast path

1. Open your GitHub repository.
2. Upload both files to the repository root, or to the `docs/` folder.
3. Go to `Settings` -> `Pages`.
4. Choose the branch and folder you uploaded to.
5. Save. GitHub will provide a public URL after the Pages build finishes.

If the files are placed at the repository root, the public URL usually looks like:

`https://YOUR_USERNAME.github.io/YOUR_REPOSITORY/`

